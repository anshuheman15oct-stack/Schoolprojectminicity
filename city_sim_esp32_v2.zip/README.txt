CITY SIM  ->  ESP32 + WS2812B LEDs
==================================
1. Arduino IDE -> Boards Manager -> install "esp32 by Espressif Systems".
   Board: "ESP32 Dev Module".  No extra libraries are needed.
2. Open city_esp32/city_esp32.ino  (index_html.h must stay in the same folder).
3. Set WIFI_SSID / WIFI_PASS at the top.  Leave SSID empty to use the
   built-in hotspot "CitySim-ESP32" (password citysim123) -> http://192.168.4.1
4. Upload.  Open Serial Monitor (115200) to see the address,
   or browse to  http://citysim.local
5. In the page tap  "💡 LEDs":
     - tick the LEDs you wired and choose each LED's D pin
     - "Select area": drag a box on the map (two fingers = pan/zoom), Done
     - press "Save to ESP32"  (pins + areas + colours are stored in flash)
   Changing a pin or the on/off box applies to the ESP32 at once (a message
   shows e.g. "LED1->D5").  "Save to ESP32" stores areas + colours in flash.
   "Test LED" flashes red/green/blue/white on that LED.

Wiring per LED: DIN -> D pin (330 ohm in series), 5V -> 5V, GND -> GND (common).
Up to 8 LEDs (ESP32 hardware limit).  Pins offered: D2 D4 D5 D13 D14 D15 D16
D17 D18 D19 D21 D22 D23 D25 D26 D27 D32 D33.

Colours (editable in the panel):
  traffic red | water blue | electricity yellow | air quality purple |
  sewage green | parking full cyan | court backlog magenta
Several problems in one area = their colours are mixed (weighted average),
brightness grows with the worst problem. No problem = dim green (optional).
If the page stops sending for 60 s the LEDs switch off (IDLE_OFF_MS).

Trigger levels:
  In the "LED panel" every problem has a slider "lights at >= X%".
  The LED only shows that problem's colour once its problem % (the number
  shown in each LED's "now:" line, e.g. "Traffic 45%") reaches X.
  Default 12% for all.  Press "Save to ESP32" to store them in flash.

Map (updated to match the physical model):
  Roundabout in the centre with a west road, an east road and a south road.
  Top-left red-roof houses, top-middle white towers, top-right offices (+courts),
  bottom-left solar panel + mega parking, bottom-right grey industrial blocks.
  LED areas saved on the ESP32 for the OLD map are ignored once (the areas
  would point at the wrong place); every LED starts with a default area on the
  new map.  Adjust with "Select area" and press "Save to ESP32" again.
