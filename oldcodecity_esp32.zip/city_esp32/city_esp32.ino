/*
  ===================================================================
   City Simulation  ->  ESP32 + WS2812B status LEDs
  ===================================================================
   * The ESP32 hosts the whole city-simulation web page (see index_html.h).
   * Open the page on your phone/PC, tap  "💡 LEDs"  to:
        - choose which D pin each LED is connected to
        - draw an area of the map for every LED
        - pick the colours used for each problem
   * The page works out the problems in each area (traffic = red,
     water = blue, electricity = yellow, ...) and sends the colours
     to this sketch. Mixed problems give a mixed colour.

   LEDs : up to 8 single WS2812B pixels, each on its OWN pin (not a strip).
   Libs : none - uses only the ESP32 Arduino core
          (WiFi, WebServer, ESPmDNS, Preferences).
   Board: "ESP32 Dev Module"  (Espressif esp32 core 2.x or 3.x)

   Wiring (for every LED):  DIN -> chosen D pin (via ~330 ohm resistor)
                            VCC -> 5V      GND -> GND (common with ESP32)
   Tip: a 100-470 uF capacitor across the LED supply helps; if a LED
   flickers at 3.3 V data, use a 74HCT125 / 74AHCT1G125 level shifter.
  ===================================================================
*/
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include "index_html.h"

// ---------------------- USER SETTINGS ----------------------------
const char* WIFI_SSID = "";            // your Wi-Fi name  (empty = start own hotspot)
const char* WIFI_PASS = "";            // your Wi-Fi password
const char* AP_SSID   = "CitySim-ESP32";   // hotspot name used if Wi-Fi fails
const char* AP_PASS   = "citysim123";      // hotspot password (min. 8 characters)
const char* HOSTNAME  = "citysim";         // open  http://citysim.local
const uint32_t IDLE_OFF_MS = 60000;    // LEDs switch off if the page stops sending (0 = never)
// -----------------------------------------------------------------

#define MAX_LEDS 8                     // ESP32 RMT hardware limit = 8 pixels on 8 pins
const int8_t DEFAULT_PINS[MAX_LEDS] = {13, 14, 16, 17, 18, 19, 21, 22};
// GPIOs that are safe for output (no flash pins, no input-only pins 34-39)
const int8_t ALLOWED[] = {2, 4, 5, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33};

WebServer   server(80);
Preferences prefs;

int8_t   ledPin[MAX_LEDS];
uint8_t  ledRGB[MAX_LEDS][3];
uint32_t lastUpdate = 0;
int      testLed = -1;
uint8_t  testStep = 0;
uint32_t testT = 0;

// ---------- low level pixel write (works on core 2.x and 3.x) ----------
static inline void writePixel(int pin, uint8_t r, uint8_t g, uint8_t b) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  rgbLedWrite(pin, r, g, b);
#else
  neopixelWrite(pin, r, g, b);
#endif
}

bool pinAllowed(int p) {
  for (size_t i = 0; i < sizeof(ALLOWED); i++) if (ALLOWED[i] == p) return true;
  return false;
}

void showLed(int i) {
  if (i >= 0 && i < MAX_LEDS && ledPin[i] >= 0)
    writePixel(ledPin[i], ledRGB[i][0], ledRGB[i][1], ledRGB[i][2]);
}

void setLed(int i, uint8_t r, uint8_t g, uint8_t b) {
  ledRGB[i][0] = r; ledRGB[i][1] = g; ledRGB[i][2] = b;
  showLed(i);
}

void allOff() {
  for (int i = 0; i < MAX_LEDS; i++) setLed(i, 0, 0, 0);
}

// "13,14,-1,..."  ->  ledPin[]   (invalid / duplicate pins are ignored)
void applyPins(const String& list, bool save) {
  int8_t np[MAX_LEDS];
  for (int i = 0; i < MAX_LEDS; i++) np[i] = -1;
  int idx = 0, start = 0;
  for (int pos = 0; pos <= (int)list.length() && idx < MAX_LEDS; pos++) {
    if (pos == (int)list.length() || list[pos] == ',') {
      int v = list.substring(start, pos).toInt();
      if (pinAllowed(v)) {
        bool dup = false;
        for (int k = 0; k < idx; k++) if (np[k] == v) dup = true;
        np[idx] = dup ? -1 : v;
      }
      idx++;
      start = pos + 1;
    }
  }
  for (int i = 0; i < MAX_LEDS; i++) {          // switch off pins that are no longer used
    if (ledPin[i] >= 0 && ledPin[i] != np[i]) writePixel(ledPin[i], 0, 0, 0);
  }
  String clean;
  for (int i = 0; i < MAX_LEDS; i++) {
    ledPin[i] = np[i];
    clean += String((int)np[i]);
    if (i < MAX_LEDS - 1) clean += ",";
    ledRGB[i][0] = ledRGB[i][1] = ledRGB[i][2] = 0;
    showLed(i);
  }
  if (save) prefs.putString("pins", clean);
  Serial.print("LED pins: "); Serial.println(clean);
}

// ---------- HTTP handlers ----------
void cors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "*");
}

void hRoot() {
  server.sendHeader("Content-Encoding", "gzip");
  server.sendHeader("Cache-Control", "no-cache");
  server.send_P(200, "text/html", (PGM_P)INDEX_HTML_GZ, INDEX_HTML_GZ_LEN);
}

void hPing() {
  cors();
  int n = 0;
  for (int i = 0; i < MAX_LEDS; i++) if (ledPin[i] >= 0) n++;
  server.send(200, "application/json", "{\"ok\":1,\"leds\":" + String(n) + "}");
}

// /led?c=rrggbb,rrggbb,...   (one colour per LED slot)
void hLed() {
  cors();
  String c = server.arg("c");
  int idx = 0, start = 0;
  for (int pos = 0; pos <= (int)c.length() && idx < MAX_LEDS; pos++) {
    if (pos == (int)c.length() || c[pos] == ',') {
      if (pos - start == 6 && testLed < 0) {
        uint32_t v = strtoul(c.substring(start, pos).c_str(), nullptr, 16);
        uint8_t r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255;
        if (r != ledRGB[idx][0] || g != ledRGB[idx][1] || b != ledRGB[idx][2]) setLed(idx, r, g, b);
      }
      idx++;
      start = pos + 1;
    }
  }
  lastUpdate = millis();
  server.send(200, "text/plain", "ok");
}

void hCfgGet() {
  cors();
  size_t n = prefs.getBytesLength("cfg");
  if (n == 0) { server.send(200, "application/json", "{}"); return; }
  char* buf = (char*)malloc(n + 1);
  if (!buf) { server.send(500, "text/plain", "no memory"); return; }
  prefs.getBytes("cfg", buf, n);
  buf[n] = 0;
  server.send(200, "application/json", buf);
  free(buf);
}

void hCfgPost() {
  cors();
  if (server.hasArg("cfg")) {
    String c = server.arg("cfg");
    prefs.putBytes("cfg", c.c_str(), c.length());
  }
  if (server.hasArg("pins")) applyPins(server.arg("pins"), true);
  server.send(200, "text/plain", "saved");
}

void hTest() {
  cors();
  int i = server.arg("i").toInt();
  if (i >= 0 && i < MAX_LEDS && ledPin[i] >= 0) {
    testLed = i; testStep = 0; testT = 0;
  }
  server.send(200, "text/plain", "ok");
}

void hOff() {
  cors();
  allOff();
  server.send(200, "text/plain", "ok");
}

void hNotFound() {
  cors();
  if (server.method() == HTTP_OPTIONS) server.send(204);
  else server.send(404, "text/plain", "Not found");
}

// ---------- start-up ----------
void startWifi() {
  WiFi.setHostname(HOSTNAME);
  if (strlen(WIFI_SSID) > 0) {
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    Serial.print("Connecting to Wi-Fi");
    uint32_t t = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t < 15000) { delay(250); Serial.print('.'); }
    Serial.println();
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Open  http://"); Serial.print(WiFi.localIP());
    Serial.print("   or   http://"); Serial.print(HOSTNAME); Serial.println(".local");
  } else {
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASS);
    Serial.print("Hotspot '"); Serial.print(AP_SSID);
    Serial.print("'  password '"); Serial.print(AP_PASS);
    Serial.print("'  ->  open http://"); Serial.println(WiFi.softAPIP());
  }
  WiFi.setSleep(false);
  if (MDNS.begin(HOSTNAME)) MDNS.addService("http", "tcp", 80);
}

void bootAnimation() {                       // quick R-G-B check of every connected LED
  const uint8_t col[3][3] = {{40, 0, 0}, {0, 40, 0}, {0, 0, 40}};
  for (int c = 0; c < 3; c++) {
    for (int i = 0; i < MAX_LEDS; i++) setLed(i, col[c][0], col[c][1], col[c][2]);
    delay(250);
  }
  allOff();
}

void setup() {
  Serial.begin(115200);
  delay(200);
  prefs.begin("citysim", false);
  for (int i = 0; i < MAX_LEDS; i++) { ledPin[i] = -1; ledRGB[i][0] = ledRGB[i][1] = ledRGB[i][2] = 0; }
  String def;
  for (int i = 0; i < MAX_LEDS; i++) { def += String((int)DEFAULT_PINS[i]); if (i < MAX_LEDS - 1) def += ","; }
  applyPins(prefs.getString("pins", def), false);
  bootAnimation();

  startWifi();

  server.on("/", HTTP_GET, hRoot);
  server.on("/api/ping", HTTP_GET, hPing);
  server.on("/led", HTTP_GET, hLed);
  server.on("/api/cfg", HTTP_GET, hCfgGet);
  server.on("/api/cfg", HTTP_POST, hCfgPost);
  server.on("/api/test", HTTP_GET, hTest);
  server.on("/api/off", HTTP_GET, hOff);
  server.onNotFound(hNotFound);
  server.begin();
  Serial.println("Web server started");
}

void loop() {
  server.handleClient();

  // non-blocking LED test: red, green, blue, white, then back to normal
  if (testLed >= 0 && millis() - testT > 400) {
    testT = millis();
    static const uint8_t T[4][3] = {{80, 0, 0}, {0, 80, 0}, {0, 0, 80}, {80, 80, 80}};
    if (testStep < 4) setLed(testLed, T[testStep][0], T[testStep][1], T[testStep][2]);
    else { setLed(testLed, 0, 0, 0); testLed = -1; }
    testStep++;
  }

  // page closed / stopped sending -> switch LEDs off
  if (IDLE_OFF_MS && lastUpdate && millis() - lastUpdate > IDLE_OFF_MS) {
    allOff();
    lastUpdate = 0;
  }
}
